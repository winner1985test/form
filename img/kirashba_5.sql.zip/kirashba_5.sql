-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Сен 04 2023 г., 16:17
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kirashba_5`
--

-- --------------------------------------------------------

--
-- Структура таблицы `customers`
--
-- Создание: Авг 30 2023 г., 11:59
-- Последнее обновление: Авг 30 2023 г., 12:10
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id_customer` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `customers`
--

INSERT INTO `customers` (`id_customer`, `name`, `email`) VALUES
(1, 'Стручина Кира Геннадьевна', 'volosunov@mail.ru'),
(2, 'Волосунов Михаил', 'volosunov@mail.ru'),
(3, 'Косьяненко Светлана', 'kosyanenko@mail.ru'),
(4, 'Ибрагимов Сергей', 'ibragimov@mail.ru'),
(5, 'Волошин Андрей', 'voloshin@mail.ru'),
(6, 'Кирилов Олег', 'kirillov@mail.ru'),
(7, 'Красный Михаил', 'krasniy@mail.ru'),
(8, 'Кожин Сергей', 'kojin@mail.ru'),
(9, 'Мандаринова Наталья', 'mandarin@mail.ru'),
(10, 'Кировский Саша', 'kirovsky@mail.ru'),
(11, 'Цветкова Алена', 'cvetkova@mail.ru'),
(12, 'Домовенок Ольга', 'domovenok@mail.ru'),
(13, 'Добрая Светлана', 'dobraya@mail.ru'),
(14, 'Хитренький Сергей', 'hitrinkiy@mail.ru'),
(15, 'Богач Алексей', 'bogach@mail.ru'),
(16, 'Безденежный Георгий', 'bezdenej@mail.ru'),
(17, 'Колючий Виктор', 'koluch@mail.ru'),
(18, 'Светлая Елена', 'svetlaya@mail.ru');

-- --------------------------------------------------------

--
-- Структура таблицы `incoming`
--
-- Создание: Авг 30 2023 г., 12:00
-- Последнее обновление: Авг 30 2023 г., 12:12
--

DROP TABLE IF EXISTS `incoming`;
CREATE TABLE `incoming` (
  `id_incoming` int(11) NOT NULL,
  `id_vendor` int(11) NOT NULL,
  `date_incoming` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `incoming`
--

INSERT INTO `incoming` (`id_incoming`, `id_vendor`, `date_incoming`) VALUES
(1, 7, '2023-11-17'),
(2, 10, '2023-03-02'),
(3, 11, '2023-07-01'),
(4, 2, '2023-04-27'),
(5, 5, '2023-12-25'),
(6, 3, '2023-12-25'),
(7, 11, '2023-07-11'),
(8, 12, '2023-03-15'),
(9, 2, '2023-01-30'),
(10, 5, '2023-01-24'),
(11, 8, '2023-12-28'),
(12, 8, '2023-01-21'),
(13, 2, '2023-02-10'),
(14, 3, '2023-05-22'),
(15, 3, '2023-09-28'),
(16, 4, '2023-10-11'),
(17, 8, '2023-09-05');

-- --------------------------------------------------------

--
-- Структура таблицы `magazine_incoming`
--
-- Создание: Авг 30 2023 г., 12:01
-- Последнее обновление: Авг 30 2023 г., 12:16
--

DROP TABLE IF EXISTS `magazine_incoming`;
CREATE TABLE `magazine_incoming` (
  `id_incoming` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `magazine_incoming`
--

INSERT INTO `magazine_incoming` (`id_incoming`, `id_product`, `quantity`) VALUES
(2, 4, 5),
(2, 5, 43),
(2, 10, 102),
(3, 2, 15),
(3, 3, 20),
(4, 11, 149),
(6, 6, 220),
(7, 3, 198),
(9, 9, 131),
(10, 8, 11),
(11, 1, 482),
(11, 2, 324),
(12, 4, 100),
(13, 14, 12),
(16, 1, 88);

-- --------------------------------------------------------

--
-- Структура таблицы `magazine_sales`
--
-- Создание: Авг 30 2023 г., 12:00
-- Последнее обновление: Авг 30 2023 г., 12:15
--

DROP TABLE IF EXISTS `magazine_sales`;
CREATE TABLE `magazine_sales` (
  `id_sale` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `magazine_sales`
--

INSERT INTO `magazine_sales` (`id_sale`, `id_product`, `quantity`) VALUES
(1, 9, 131),
(2, 1, 60),
(2, 4, 482),
(3, 10, 102),
(5, 5, 15),
(5, 7, 150),
(5, 13, 5),
(7, 6, 100),
(8, 3, 98),
(8, 11, 88),
(9, 8, 149),
(11, 14, 11),
(12, 12, 2),
(13, 15, 23),
(14, 2, 124);

-- --------------------------------------------------------

--
-- Структура таблицы `prices`
--
-- Создание: Авг 30 2023 г., 12:00
-- Последнее обновление: Авг 30 2023 г., 12:15
--

DROP TABLE IF EXISTS `prices`;
CREATE TABLE `prices` (
  `id_product` int(11) NOT NULL,
  `date_price_changes` date NOT NULL,
  `price` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `prices`
--

INSERT INTO `prices` (`id_product`, `date_price_changes`, `price`) VALUES
(2, '2023-02-01', 3000.00),
(2, '2023-02-10', 13000.00),
(2, '2023-02-22', 8000.00),
(3, '2023-03-02', 2000.00),
(3, '2023-03-08', 17000.00),
(3, '2023-03-14', 10000.00),
(4, '2023-04-13', 12000.00),
(6, '2023-06-11', 16000.00),
(6, '2023-06-22', 4000.00),
(7, '2023-07-22', 14000.00),
(9, '2023-09-07', 7000.00),
(10, '2023-10-15', 5000.00),
(11, '2023-11-13', 6000.00),
(11, '2023-11-17', 1000.00),
(11, '2023-11-20', 9000.00),
(11, '2023-11-28', 15000.00),
(12, '2023-12-28', 11000.00);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--
-- Создание: Авг 30 2023 г., 12:00
-- Последнее обновление: Авг 30 2023 г., 12:12
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id_product` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `sale` enum('1','0') NOT NULL,
  `weight` double(8,2) NOT NULL,
  `price` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id_product`, `title`, `brand`, `category`, `country`, `sale`, `weight`, `price`) VALUES
(1, 'Стиральная машина Weissgauff WM 4947 DC Inverter Steam с инверторным двигателем и паром, белый', 'Weissgauff', 'Стиральные машины', 'Южная Корея', '1', 45.20, 0.00),
(2, 'Стиральная машина ATLANT CMA 60У108-00, белый', 'ATLANT', 'Стиральные машины', 'Россия', '1', 36.20, 0.00),
(3, 'Стиральная машина NORDFROST WM 6100 W, 6 кг загрузка, 40 л объем, 1000об/мин,8 программ, отсрочка ст', 'NORDFROST', 'Стиральные машины', 'Италия', '1', 60.20, 0.00),
(4, 'Стиральная машина Indesit EWSB 5085 CIS, белый', 'Indesit', 'Стиральные машины', 'Япония', '1', 43.90, 0.00),
(5, 'Стиральная машина Kraft KF-ENC 6105 W, загрузка до 6 кг, 16 программ стирки', 'Kraft', 'Стиральные машины', 'Китай', '0', 23.90, 0.00),
(6, 'Стиральная машина Weissgauff WM 4947 DC Inverter Steam с инверторным двигателем и паром, белый', 'Weissgauff', 'Стиральные машины', 'Южная Корея', '0', 44.90, 0.00),
(7, 'Холодильник Indesit ES 16', 'Indesit', 'Холодильники', 'Италия', '1', 65.00, 0.00),
(8, 'Холодильник Bosfor RF 049, белый', 'Bosfor', 'Холодильники', 'Германия', '0', 36.00, 0.00),
(9, 'Холодильник Kraft BC(W)-50 однокамерный, 50 л, мини холодильник для напитков, холодильник барный, бе', 'Kraft', 'Холодильники', 'Польша', '1', 11.00, 0.00),
(10, 'Холодильник Bosch KGN39LB316, черный', 'Bosch', 'Холодильники', 'Германия', '1', 12.00, 0.00),
(11, 'Холодильник GINZZU NFK-3552 No Frost, 355л, двухкамерный, темно серый', 'GINZZU', 'Холодильники', 'Польша', '1', 49.20, 0.00),
(12, 'Плита Hotpoint-Ariston HS5V5PHW', 'Hotpoint-Ariston', 'Плиты', 'Вьетнам', '0', 8.00, 0.00),
(13, 'Электрическая плита Weissgauff WES E2V00 WS', 'Weissgauff', 'Плиты', 'Южная Корея', '1', 6.90, 0.00),
(14, 'Плита Электрическая Лысьва EF3001MK00 черный стеклокерамика (без крышки)', 'Лысьва', 'Плиты', 'Узбекистан', '1', 23.20, 0.00),
(15, 'Электрическая плита Bosch HKA050020Q', 'Bosch', 'Плиты', 'Германия', '1', 22.00, 0.00),
(16, 'Посудомоечная машина Weissgauff TDW 4006, белый', 'Weissgauff', 'Посудомоечные машины', 'Южная Корея', '0', 22.40, 0.00),
(17, 'Встраиваемая посудомоечная машина Ginzzu DC602 60см, 12 комплектов, средство 3в1', 'Ginzzu', 'Посудомоечные машины', 'xxx', '1', 30.00, 0.00),
(18, 'Посудомоечная машина Weissgauff TDW 4017, белый', 'Weissgauff', 'Посудомоечные машины', 'Южная Корея', '1', 41.00, 0.00),
(19, 'Посудомоечная машина Weissgauff TDW 4017 D, черный', 'Weissgauff', 'Посудомоечные машины', 'Южная Корея', '1', 42.20, 0.00),
(20, 'Беспроводной пылесос BQ VC1002H Gray-blue', 'BQ', 'Пылесосы', 'Россия', '1', 24.00, 0.00),
(21, 'Робот-пылесос SAFERET VL-4000, черный', 'SAFERET', 'Пылесосы', 'Казахстан', '1', 2.10, 0.00),
(22, 'Пылесос вертикальный для дома Enchen Vacuum Cleaner V1 компактный', 'xx', 'Пылесосы', 'Китай', '0', 1.50, 0.00),
(23, 'Проводной вертикальный пылесос Xiаоmi Futula V2, черный. Глобальная версия.', 'Xiаоmi', 'Пылесосы', 'Корея', '0', 1.20, 0.00),
(24, 'Беспроводной пылесос BQ VC0802H Grey-Blue', 'BQ', 'Пылесосы', 'Россия', '1', 0.50, 0.00),
(25, 'Робот-пылесос SAFERET VL-4000, белый', 'SAFERET', 'Пылесосы', 'Казахстан', '1', 17.00, 0.00),
(26, 'Сплит-система HISENSE AS-10HW4SYDTG5', 'HISENSE', 'Кондиционер', 'Россия', '0', 14.10, 0.00),
(27, 'Сплит-система инверторная Domfy DCW-AC-09-1i, настенный кондиционер воздуха для дома, площадь до 20 ', 'Domfy', 'Кондиционер', 'Россия', '1', 19.20, 0.00),
(28, 'Кондиционер сплит-система LG S4UW09JA3AD.EC6GLVT Dual Inverter', 'LG', 'Кондиционер', 'Южная Корея', '0', 20.80, 0.00);

-- --------------------------------------------------------

--
-- Структура таблицы `sale`
--
-- Создание: Авг 30 2023 г., 11:59
-- Последнее обновление: Авг 30 2023 г., 12:12
--

DROP TABLE IF EXISTS `sale`;
CREATE TABLE `sale` (
  `id_sale` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `date_sale` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sale`
--

INSERT INTO `sale` (`id_sale`, `id_customer`, `date_sale`) VALUES
(1, 1, '2023-12-25'),
(2, 2, '2023-12-28'),
(3, 3, '2023-01-21'),
(4, 2, '2023-02-10'),
(5, 1, '2023-04-27'),
(6, 4, '2023-01-30'),
(7, 6, '2023-09-28'),
(8, 4, '2023-10-11'),
(9, 7, '2023-11-17'),
(10, 8, '2023-09-05'),
(11, 10, '2023-03-02'),
(12, 12, '2023-07-01'),
(13, 11, '2023-07-11'),
(14, 10, '2023-03-15'),
(15, 1, '2023-01-24'),
(16, 3, '2023-05-22');

-- --------------------------------------------------------

--
-- Структура таблицы `vendors`
--
-- Создание: Авг 30 2023 г., 11:59
-- Последнее обновление: Авг 30 2023 г., 12:11
--

DROP TABLE IF EXISTS `vendors`;
CREATE TABLE `vendors` (
  `id_vendor` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `vendors`
--

INSERT INTO `vendors` (`id_vendor`, `name`, `city`, `address`) VALUES
(1, 'Поставщик 1', 'Самара', 'ул. Красная, д.11'),
(2, 'Поставщик 2', 'Рязань', 'пл. Ленина, д.18'),
(3, 'Поставщик 3', 'Санкт-Петербург', 'ул. Еременко, д.5'),
(4, 'Поставщик 4', 'Ростов-на-Дону', 'ул. Большая садовая, д.4'),
(5, 'Поставщик 5', 'Москва', 'ул. Прямая, д.4'),
(6, 'Поставщик 6', 'Люберцы', 'ул. Абрисовая, д.55'),
(7, 'Поставщик 7', 'Котельники', 'ул. Извилистая, д.23'),
(8, 'Поставщик 8', 'Киров', 'ул. Длинная, д.24'),
(9, 'Поставщик 9', 'Екатеринбург', 'ул. Белая, д.1'),
(10, 'Поставщик 10', 'Новосибирск', 'ул. Краснодарская, д.99'),
(11, 'Поставщик 11', 'Рязань', 'ул. Контимирова, д.72'),
(12, 'Поставщик 12', 'Минск', 'ул. Есенина, д.25'),
(13, 'Поставщик 13', 'Одинцово', 'ул. Пушкина, д.42'),
(14, 'Поставщик 14', 'Химки', 'ул. Революции, д.2'),
(15, 'Поставщик 15', 'Тверь', 'ул. первого мая, д.7');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id_customer`);

--
-- Индексы таблицы `incoming`
--
ALTER TABLE `incoming`
  ADD PRIMARY KEY (`id_incoming`),
  ADD KEY `id_vendor` (`id_vendor`);

--
-- Индексы таблицы `magazine_incoming`
--
ALTER TABLE `magazine_incoming`
  ADD PRIMARY KEY (`id_incoming`,`id_product`),
  ADD KEY `id_product` (`id_product`);

--
-- Индексы таблицы `magazine_sales`
--
ALTER TABLE `magazine_sales`
  ADD PRIMARY KEY (`id_sale`,`id_product`),
  ADD KEY `id_product` (`id_product`);

--
-- Индексы таблицы `prices`
--
ALTER TABLE `prices`
  ADD PRIMARY KEY (`id_product`,`date_price_changes`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id_product`);

--
-- Индексы таблицы `sale`
--
ALTER TABLE `sale`
  ADD PRIMARY KEY (`id_sale`),
  ADD KEY `id_customer` (`id_customer`);

--
-- Индексы таблицы `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id_vendor`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `customers`
--
ALTER TABLE `customers`
  MODIFY `id_customer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `incoming`
--
ALTER TABLE `incoming`
  MODIFY `id_incoming` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT для таблицы `sale`
--
ALTER TABLE `sale`
  MODIFY `id_sale` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id_vendor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `incoming`
--
ALTER TABLE `incoming`
  ADD CONSTRAINT `incoming_ibfk_1` FOREIGN KEY (`id_vendor`) REFERENCES `vendors` (`id_vendor`);

--
-- Ограничения внешнего ключа таблицы `magazine_incoming`
--
ALTER TABLE `magazine_incoming`
  ADD CONSTRAINT `magazine_incoming_ibfk_1` FOREIGN KEY (`id_incoming`) REFERENCES `incoming` (`id_incoming`),
  ADD CONSTRAINT `magazine_incoming_ibfk_2` FOREIGN KEY (`id_product`) REFERENCES `products` (`id_product`);

--
-- Ограничения внешнего ключа таблицы `magazine_sales`
--
ALTER TABLE `magazine_sales`
  ADD CONSTRAINT `magazine_sales_ibfk_1` FOREIGN KEY (`id_sale`) REFERENCES `sale` (`id_sale`),
  ADD CONSTRAINT `magazine_sales_ibfk_2` FOREIGN KEY (`id_product`) REFERENCES `products` (`id_product`);

--
-- Ограничения внешнего ключа таблицы `prices`
--
ALTER TABLE `prices`
  ADD CONSTRAINT `prices_ibfk_1` FOREIGN KEY (`id_product`) REFERENCES `products` (`id_product`);

--
-- Ограничения внешнего ключа таблицы `sale`
--
ALTER TABLE `sale`
  ADD CONSTRAINT `sale_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `customers` (`id_customer`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
